<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Homework 2</title>
    <meta name="description" content="Homework 2 Summary">
    <meta name="author" content="Jen Chen">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
<?php
    require_once 'connect.php'; //connect to SQL database
?>
    
<?php
    $nameErr = "";
    $name = "";
    
    $textval = "/[A-Za-z'\s]/";
    
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $search = $_POST["name"];
        // letters, spaces, and apostrophes only
        if(!preg_match($textval,$name)) {
            $nameErr = "Please enter a valid name. (letters, spaces, and apostrophes only)";
        }
    }
?>
    
    <form action="homework2search.php" method="post">
        Search by Name: <input type="text" name="name" placeholder="Jane Doe" required="required" value="<?php echo $search;?>">
        <span class="error"> <?php echo $searchErr;?></span>
    </form>
    
<?php
    if(isset($_POST['name'])){
        name:
        $name = $_POST['name'];
        $query = "SELECT * FROM ORDERS
        WHERE name = '$name'";
        if($name=='') goto end;
        echo "Order Information: " . "<br>";

        $result = $conn->query($query);
        if (!$result) die("Fatal Error when querying SQL table with search.");
        
        echo "<table>";
        echo "<tr><th>Order ID</th>
        <th>Name</th>
        <th>Address</th>
        <th>City</th>
        <th>State</th>
        <th>Zip Code</th>
        <th>Phone Number</th>
        <th>Color</th>
        <th>Quantity</th>
        <th>Delivery</th>
        <th>Total Cost</th>
        <th>Order Date</th></tr>";
        
        $rows = $result->num_rows;    
        for($j=0; $j<$rows; ++$j) {
        // data_seek is a php function used to collect data from a particular row ($j)  
            $result->data_seek($j);
            echo "<tr><td>".htmlspecialchars($result->fetch_assoc()['orderID']).'</td>';
            $result->data_seek($j);
            echo '<td>'.htmlspecialchars($result->fetch_assoc()['name']).'</td>';
            $result->data_seek($j);
            echo '<td>'.htmlspecialchars($result->fetch_assoc()['address']).'</td>';
            $result->data_seek($j);
            echo '<td>'.htmlspecialchars($result->fetch_assoc()['city']).'</td>';
            $result->data_seek($j);
            echo '<td>'.htmlspecialchars($result->fetch_assoc()['state']).'</td>';
            $result->data_seek($j);
            echo '<td>'.htmlspecialchars($result->fetch_assoc()['zipcode']).'</td>';
            $result->data_seek($j);
            echo '<td>'.htmlspecialchars($result->fetch_assoc()['phonenumber']).'</td>';
            $result->data_seek($j);
            echo '<td>'.htmlspecialchars($result->fetch_assoc()['color']).'</td>';
            $result->data_seek($j);
            echo '<td>'.htmlspecialchars($result->fetch_assoc()['quantity']).'</td>';
            $result->data_seek($j);
            echo '<td>'.htmlspecialchars($result->fetch_assoc()['delivery']).'</td>';
            $result->data_seek($j);
            echo '<td>'.htmlspecialchars($result->fetch_assoc()['totalcost']).'</td>';
            $result->data_seek($j);
            echo '<td>'.htmlspecialchars($result->fetch_assoc()['orderdate']).'</td></tr>';
        }
        echo "</table>";
    }
    end:
    mysqli_close($conn);
?>
</body>
    
</html>