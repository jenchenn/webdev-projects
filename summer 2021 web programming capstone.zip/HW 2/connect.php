<?php
//connect to sql database
    $host = "localhost"; 
    $user = "jec229";
    $password = "Student_4260471";
    $dbname = "jec229";
    $conn = mysqli_connect($host, $user, $password, $dbname);

    if (mysqli_connect_errno()) {
        die("Database connection failed: ".mysqli_connect_error()." (".mysqli_connect_errno().")");
    }
?>