<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Homework 2</title>
    <meta name="description" content="Homework 2 Summary">
    <meta name="author" content="Jen Chen">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
<?php
    require_once 'connect.php';
    $query = "SELECT * FROM ORDERS";
    $result = $conn->query($query);
    if (!$result) die("Fatal Error when querying SQL table.");
    $rows = $result->num_rows;
    
    echo "<table>";
    echo "<tr><th>Order ID</th>
        <th>Name</th>
        <th>Address</th>
        <th>City</th>
        <th>State</th>
        <th>Zip Code</th>
        <th>Phone Number</th>
        <th>Color</th>
        <th>Quantity</th>
        <th>Delivery</th>
        <th>Total Cost</th>
        <th>Order Date</th></tr>";
    
    for ($j=0; $j<$rows; ++$j) {
        // data_seek is a php function used to collect data from a particular row ($j)  
       $result->data_seek($j);
       echo "<tr><td>".htmlspecialchars($result->fetch_assoc()['orderID']).'</td>';
        $result->data_seek($j);
       echo '<td>'.htmlspecialchars($result->fetch_assoc()['name']).'</td>';
        $result->data_seek($j);
       echo '<td>'.htmlspecialchars($result->fetch_assoc()['address']).'</td>';
        $result->data_seek($j);
       echo '<td>'.htmlspecialchars($result->fetch_assoc()['city']).'</td>';
        $result->data_seek($j);
       echo '<td>'.htmlspecialchars($result->fetch_assoc()['state']).'</td>';
        $result->data_seek($j);
       echo '<td>'.htmlspecialchars($result->fetch_assoc()['zipcode']).'</td>';
        $result->data_seek($j);
       echo '<td>'.htmlspecialchars($result->fetch_assoc()['phonenumber']).'</td>';
        $result->data_seek($j);
       echo '<td>'.htmlspecialchars($result->fetch_assoc()['color']).'</td>';
        $result->data_seek($j);
       echo '<td>'.htmlspecialchars($result->fetch_assoc()['quantity']).'</td>';
        $result->data_seek($j);
       echo '<td>'.htmlspecialchars($result->fetch_assoc()['delivery']).'</td>';
        $result->data_seek($j);
       echo '<td>'.htmlspecialchars($result->fetch_assoc()['totalcost']).'</td>';
        $result->data_seek($j);
       echo '<td>'.htmlspecialchars($result->fetch_assoc()['orderdate']).'</td>';
       echo "</tr>";
    }
    echo "</table>";
    mysqli_close($conn);
?>
</body>

</html>