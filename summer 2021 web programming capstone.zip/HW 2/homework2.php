<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Homework 2</title>
    <meta name="description" content="Homework 2">
    <meta name="author" content="Jen Chen">
    <link rel="stylesheet" href="styles.css">

    <style>
        .error {
            color: red;
        }

    </style>
</head>

<body>
<?php
    require_once 'connect.php'; //connect to SQL database 
?>
    
<?php
    $nameErr = $addressErr = $cityErr = $stateErr = $zipcodeErr = $phonenumberErr = $colorErr = $quantityErr = $deliveryErr = "";
    $orderID = $name = $address = $city = $state = $zipcode = $phonenumber = $color = $quantity = $delivery = $totalcost = $orderdate = "";
    
    $textval = "/[A-Za-z'\s]/";
    $zipval = "/^[0-9]{5}([- ]?[0-9]{4})?$/";
    $phoneval = "/^(\d{3})-(\d{3})-(\d{4})$/";
    $quantityval = "/^[1-9]|10$/";
    
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $orderID = $_POST["orderID"];
        
        $name = $_POST["name"];
        // letters, spaces, and apostrophes only
        if(!preg_match($textval,$name)) {
            $nameErr = "Please enter a valid name. (letters, spaces, and apostrophes only)";
        }
    
        $address = $_POST["address"];
        
        $city = $_POST["city"];
        // letters, spaces, and apostrophes only
        if(!preg_match($textval,$city)) {
            $cityErr = "Please enter a valid city. (letters, spaces, and apostrophes only)";
        }
        
        $state = $_POST["state"];
        
        $zipcode = $_POST["zipcode"];// 5 digits
        if(!preg_match($zipval,$zipcode)) {
            $zipcodeErr = "Please enter a valid zipcode. (must be 5 digits)";
        }
        
        $phonenumber = $_POST["phonenumber"];
        // dashes
        if (!preg_match($phoneval,$phonenumber)) {
            $phonenumberErr = "Please enter a valid phone number. (use dashes)";
        }
        
        $color = $_POST["color"];
        
        $quantity = $_POST["quantity"];
        // 1-10 only
        if (!preg_match($quantityval,$quantity)) {
            $quantityErr = "You may only purchase a minimum of 1 or a maximum of 10.";
        }
        
        if (empty($_POST["delivery"])) {
        $deliveryErr = "Please select a delivery option.";
        } else {
        $delivery = $_POST["delivery"];
        }   
        
        $totalcost = ((14.99*$quantity)+$delivery);
        $orderdate = date('m/d/Y h:i a', time());
    }
?>

    <h1>JUNIMO</h1>
    <h3>Be the first to adopt one of our limited edition Stardew Valley Junimos. Now only $14.99 each!</h3>
    <div class="img"><img src="junimo.png" alt="junimo" height="125"></div>
    <h4>What are Junimos?</h4>
    <p>Junimos are forest spirits that have taken up residence in the broken down Community Center of Stardew Valley. They are feisty at first but once you get to know them, theyre the sweetest and most living creatures!</p><br>
    <p><span class="error"></span></p>

    <form action="homework2.php" method="post">
        Name: <input type="text" name="name" placeholder="John Doe" required="required" value="<?php echo $name;?>">
        <span class="error"> <?php echo $nameErr;?></span>
        <br><br>
        Street Address: <input type="text" name="address" placeholder="123 ABC St." required="required" value="<?php echo $address;?>">
        <span class="error"> <?php echo $addressErr;?></span><br><br>
        City: <input type="text" name="city" placeholder="City" required="required" value="<?php echo $city;?>">
        <span class="error"> <?php echo $cityErr;?></span>
        <br><br>
        State: <input list="states" name="state" placeholder="State" required="required" value="<?php echo $state;?>">
        <span class="error"> <?php echo $stateErr;?></span>
        <br><br>
        <datalist id="states">
            <option value="AL">Alabama</option>
            <option value="AK">Alaska</option>
            <option value="AZ">Arizona</option>
            <option value="AR">Arkansas</option>
            <option value="CA">California</option>
            <option value="CO">Colorado</option>
            <option value="CT">Connecticut</option>
            <option value="DE">Delaware</option>
            <option value="DC">District Of Columbia</option>
            <option value="FL">Florida</option>
            <option value="GA">Georgia</option>
            <option value="HI">Hawaii</option>
            <option value="ID">Idaho</option>
            <option value="IL">Illinois</option>
            <option value="IN">Indiana</option>
            <option value="IA">Iowa</option>
            <option value="KS">Kansas</option>
            <option value="KY">Kentucky</option>
            <option value="LA">Louisiana</option>
            <option value="ME">Maine</option>
            <option value="MD">Maryland</option>
            <option value="MA">Massachusetts</option>
            <option value="MI">Michigan</option>
            <option value="MN">Minnesota</option>
            <option value="MS">Mississippi</option>
            <option value="MO">Missouri</option>
            <option value="MT">Montana</option>
            <option value="NE">Nebraska</option>
            <option value="NV">Nevada</option>
            <option value="NH">New Hampshire</option>
            <option value="NJ">New Jersey</option>
            <option value="NM">New Mexico</option>
            <option value="NY">New York</option>
            <option value="NC">North Carolina</option>
            <option value="ND">North Dakota</option>
            <option value="OH">Ohio</option>
            <option value="OK">Oklahoma</option>
            <option value="OR">Oregon</option>
            <option value="PA">Pennsylvania</option>
            <option value="RI">Rhode Island</option>
            <option value="SC">South Carolina</option>
            <option value="SD">South Dakota</option>
            <option value="TN">Tennessee</option>
            <option value="TX">Texas</option>
            <option value="UT">Utah</option>
            <option value="VT">Vermont</option>
            <option value="VA">Virginia</option>
            <option value="WA" selected="selected">Washington</option>
            <option value="WV">West Virginia</option>
            <option value="WI">Wisconsin</option>
            <option value="WY">Wyoming</option>
        </datalist>
        Zip Code: <input type="text" name="zipcode" placeholder="12345" required="required" value="<?php echo $zipcode;?>">
        <span class="error"> <?php echo $zipcodeErr;?></span><br><br>

        Phone Number: <input type="tel" name="phonenumber" placeholder="123-456-7890" required="required" value="<?php echo $phonenumber;?>">
        <span class="error"> <?php echo $phonenumberErr;?></span>
        <br><br>

        Color: <input list="colors" name="color" placeholder="Color" required="required" value="<?php echo $color;?>">
        <span class="error"> <?php echo $colorErr;?></span><br><br>
        <datalist id="colors">
            <option value="Purple"></option>
            <option value="Blue"></option>
            <option value="Green"></option>
            <option value="Yellow"></option>
            <option value="Orange"></option>
            <option value="Red"></option>
            <option value="Pink"></option>
            <option value="Bright Green"></option>
            <option value="Turquoise"></option>
            <option value="Light Pink"></option>
            <option value="Mint Green"></option>
            <option value="White"></option>
            <option value="Gray"></option>
            <option value="Black"></option>
        </datalist>
        Quantity: <input type=number name="quantity" placeholder="1-10" required="required" min=1 max=10 value="<?php echo $quantity;?>">
        <span class="error"> <?php echo $quantityErr;?></span><br><br>

        Delivery:<br>
        <input type="radio" name="delivery" <?php if (isset($delivery) && $delivery=="free") echo "checked";?> value=0.00>Customer Pick Up - Free
        <br>
        <input type="radio" name="delivery" <?php if (isset($delivery) && $delivery=="1day") echo "checked";?> value=4.99>One-day Shipping - $4.99
        <br>
        <input type="radio" name="delivery" <?php if (isset($delivery) && $delivery=="3day") echo "checked";?> value=2.99>Three-day Shipping - $2.99
        <br>
        <input type="radio" name="delivery" <?php if (isset($delivery) && $delivery=="moredays") echo "checked";?> value=0.99>Five to Seven Business Days Shipping - $0.99
        <span class="error"> <?php echo $deliveryErr;?></span>
        <br><br>
        <input type="submit" name="submit" value="Submit">
    </form>
    
<?php
    $gettable = "SELECT * FROM jec229.ORDERS";
    $result = $conn->query($gettable);
    if (!$result) die("Fatal Error when querying SQL table first time.");
    $rows = $result->num_rows;
    
    //take all values from form data
    if (isset($_POST['submit'])) {
        $orderID = $_POST['orderID'];
        $name = $_POST['name'];
        $address = $_POST['address'];
        $city = $_POST['city'];
        $state = $_POST['state'];
        $zipcode = $_POST['zipcode'];
        $phonenumber = $_POST['phonenumber'];
        $color = $_POST['color'];
        $quantity = $_POST['quantity'];
        $delivery = $_POST['delivery'];
        $totalcost = $_POST['totalcost'];
        $orderdate = $_POST['orderdate'];
        
        //query for inserting data
        $query = "INSERT INTO `jec229`.`ORDERS` (`orderID`, `name`, `address`, `city`, `state`, `zipcode`, `phonenumber`, `color`, `quantity`, `delivery`, `totalcost`, `orderdate`) VALUES ('$orderID', '$name', '$address', '$city', '$state', '$zipcode', '$phonenumber', '$color', '$quantity', '$delivery', '$totalcost', '$orderdate')"; 
        
        echo "<br><b>You have successfully submitted an order!</b><br><br>";
        echo $quantity." ".$color." Junimos with a delivery fee of $".$delivery." will be sent to the following address: <br><br>";
        echo $name."<br>".$address."<br>",$city.", ".$state." ".$zipcode;
        echo "<br><br>";
        echo "Total: $".$totalcost."<br>";
        } 
        
        $result = $conn->query($query);
        if (!$result) {
            echo "Debugging errno: ".mysqli_connect_errno($conn).PHP_EOL;
            echo "Debugging error: ".mysqli_connect_error($conn).PHP_EOL;
        }
    mysqli_close($conn);   
?>
</body>

</html>
