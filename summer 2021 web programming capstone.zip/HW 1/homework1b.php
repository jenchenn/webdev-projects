<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Homework 1</title>
    <meta name="description" content="Homework 1 Part B">
    <meta name="author" content="Jen Chen">
    <link rel="stylesheet" href="styles.css">
</head>

<body>

    <?php
    echo "Congratulations, ".$_POST['name'].", you have completed the quiz!";
    echo "<br><br>";
    if($_POST['breed']=="Pug") {
        echo "Good job! You got the dropdown question right.";
    } else {
        echo "Sorry! You got the dropdown question wrong.";
    }
    echo "<br>";
    if($_POST['gender1']==male && $_POST['age1']==puppy) {
        echo "Good job! You got the checkbox question right.";
    } else {
        echo "Sorry! You got the checkbox question wrong.";
    }
    echo "<br>";
    if($_POST['yes/no']==yes) {
        echo "Good job! You got the radio button question right.";
    } else {
        echo "Sorry! You got the radio button question wrong.";
    }
    echo "<br><br>";
    if(($_POST['breed']=="Pug") && ($_POST['gender1']==male && $_POST['age1']==puppy) && ($_POST['yes/no']==yes)) {
        echo "You scored 3 out of 3.";
        echo "<br><br>";
    } else if((($_POST['breed']=="Pug") && ($_POST['gender1']==male && $_POST['age1']==puppy)) || (($_POST['breed']=="Pug") && ($_POST['yes/no']==yes)) || ($_POST['gender1']==male && $_POST['age1']==puppy) && ($_POST['yes/no']==yes)) {
        echo "You scored 2 out of 3.";
        echo "<br><br>";
    } else if($_POST['breed']=="Pug"){
        echo "You scored 1 out of 3.";
        echo "<br><br>";
    } else if($_POST['gender1']==male && $_POST['age1']==puppy){
        echo "You scored 1 out of 3.";
        echo "<br><br>";
        } else if($_POST['yes/no']==yes){
        echo "You scored 1 out of 3.";
        echo "<br><br>";
    } else {
        echo "You scored 0 out of 3.";
        echo "<br><br>";
    }
    echo "Your answers:".
         "<br>name = ".$_POST['name'].
         "<br>dropdown = ".$_POST['breed'].
         "<br>checkbox1 = ".$_POST['gender1'].
         "<br>checkbox2 = ".$_POST['gender2'].
         "<br>checkbox3 = ".$_POST['age1'].
         "<br>checkbox4 = ".$_POST['age2'].
         "<br>checkbox5 = ".$_POST['age3'].
         "<br>radio button = ".$_POST['yes/no'].
         "<br>email = ".$_POST['email'];
    echo "<br><br>";
    // timestamp
    date_default_timezone_set("America/New_York");
    echo date('m/d/Y h:i a', time());
?>

    <?php
	if($_POST['name']){
        $name = "<b>Name: </b>".$_POST['name'];
        $score = "<b>Score: </b>"."You scored a";
        $breed = "<b>Dropdown: </b>".$_POST['breed'];
        $gender1 = "<b>Checkbox1: </b>".$_POST['gender1'];
        $gender2 = "<b>Checkbox2: </b>".$_POST['gender2'];
        $age1 = "<b>Checkbox3: </b>".$_POST['age1'];
        $age2 = "<b>Checkbox4: </b>".$_POST['age2'];
        $age3 = "<b>Checkbox5: </b>".$_POST['age3'];
        $yesorno = "<b>Radio Button: </b>".$_POST['yes/no'];
        $email = "<b>Email: </b>".$_POST['email'];
        $timestamp = "<b><u>Timestamp: </b>".date('m/d/Y h:i a', time())."</u>";
        
		$text = $name.";".$score.";".$breed.";".$gender1.";".$gender2.";".$age1.";".$age2.";".$age3.";".$yesorno.";".$email.";".$timestamp.";";
		$new_file = fopen("quizresults.txt", "a") or die("unable to open file");
		fwrite($new_file, $text);
		fclose($new_file);
	}
	else{
		echo "Please enter your information.";
	}
?>

</body>

</html>
