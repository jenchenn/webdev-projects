<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Homework 1</title>
    <meta name="description" content="Homework 1 Part C & D">
    <meta name="author" content="Jen Chen">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <?php
		$contents = file_get_contents("quizresults.txt");
		$resultset = explode(";", $contents);
		foreach($resultset as $quizresults){
			echo $quizresults;
			echo "<br>";
		}
	?>
</body>

</html>
