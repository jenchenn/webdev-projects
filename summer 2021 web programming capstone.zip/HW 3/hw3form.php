<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Homework 3B</title>
    <meta name="description" content="Homework 3">
    <meta name="author" content="Jen Chen">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <h1><i>Homework 3B Javascript</i></h1><br>
    <form action="thankyou.php" method="post">
        Name: <input type="text" id="name" name="name"><br><br>
        <script>
            var nameField = document.getElementById("name");
            nameField.onfocus = function() {
                if (nameField.value == "Jane Doe") {
                    nameField.value = "";
                }
            };

            nameField.onblur = function() {
                if (nameField.value == "") {
                    nameField.value = "Jane Doe";
                }
            };
        </script>

        <script>
            //** show/hide div code found on aspsnippets.com
            function ShowHideDiv(more) {
                var revealIfMore = document.getElementById("revealIfMore");
                revealIfMore.style.display = more.checked ? "block" : "none";
            }
        </script>

        <input type="checkbox" id="more" name="more" onclick="ShowHideDiv(this)" />I would like to view more sections of this form.<br><br>
        <div id="revealIfMore" style="display:none">
            Gender: <input list="gender" id="gender" name="gender">
            <datalist id="gender">
                <option value="Male"></option>
                <option value="Female"></option>
                <option value="Other"></option>
            </datalist><br><br>
            Have you read this form and understand it in its entirety?<br>
            <input type="radio" id="yes" name="yes/no" value="yes"> Yes<br>
            <input type="radio" id="no" name="yes/no" value="no"> No<br><br>
        </div>
        <input type="submit" name="submit" value="Submit">
    </form>
</body>

</html>
