<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Homework 3B</title>
    <meta name="description" content="Homework 3">
    <meta name="author" content="Jen Chen">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
<?php
    $name = $_POST["name"];
    if (empty($_POST['name'])) {
                $name = 'thou who shall not be named';
            } else {
                $name = $_POST['name'];
            }
    echo "<h1>Thank you, ".$name."! <br> Your submission has successfully been processed.</h1>";
?>
</body>

</html>
