<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Homework 3</title>
    <meta name="description" content="Homework 3">
    <meta name="author" content="Jen Chen">
    </head>

<body>
<?php
    echo "<h1>SOURCE CODE</h1>";
    echo "<p>homework3b.html</p>"; 
    show_source("homework3b.html");
    echo "<p>hw3form.php</p>"; 
    show_source("hw3form.php");
?>