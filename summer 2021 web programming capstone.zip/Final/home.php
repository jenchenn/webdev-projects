<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Final</title>
    <meta name="description" content="Final">
    <meta name="author" content="Jen Chen">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <header>
        <h1><u><i>JEN'S TAROT READINGS</i></u></h1><br>
        <nav class="tabs">
            <li><a href="home.php">HOME</a></li>
            <li><a href="information.php">INFORMATION</a></li>
            <li><a href="appointment.php">APPOINTMENT</a></li>
            <li><a href="contact.php">CONTACT</a></li>
        </nav>
    </header>
    <?php require_once "connect.php";   // connect to sql database ?>
    <br><br><br>
    <div class="bodytext">
        <br>
        <h3>Our Purpose</h3><br>
        <h4>Here at Jen's Tarot Readings, we are dedicated to providing you with the best service possible. You will have the freedom and flexibility to book an appointment with the tarot reader of your choice. Feel free to browse through our team of tarot readers and schedule your reading today!</h4><br>
    </div>
    <footer>
        <nav class="tarotcopy">
            JEN'S TAROT READINGS &copy; 2021 English (US)
        </nav>
    </footer>
</body>

</html>
