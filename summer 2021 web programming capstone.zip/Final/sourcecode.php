<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Final</title>
    <meta name="description" content="Final">
    <meta name="author" content="Jen Chen">
    </head>

<body>
<?php
    require_once 'connect.php'; //connect to SQL database
    echo "<h1>SOURCE CODE:</h1>";
    
    echo "<img src='tarot eer diagram ss.png'>";
    echo "<p>connect.php (not shown for security purposes)</p>";
    echo "<p><u>home.php</u></p>"; 
    show_source("home.php");
    echo "<p><u>information.php</u></p>"; 
    show_source("information.php");
    echo "<p><u>appointment.php</u></p>"; 
    show_source("appointment.php");
    echo "<p><u>contact.php</u></p>"; 
    show_source("contact.php");
    echo "<p><u>insert.php</u></p>"; 
    show_source("insert.php");
    echo "<p><u>confirmation.php</u></p>"; 
    show_source("confirmation.php");
?>