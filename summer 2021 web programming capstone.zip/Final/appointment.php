<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Final</title>
    <meta name="description" content="Final">
    <meta name="author" content="Jen Chen">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <header>
        <h1><u><i>JEN'S TAROT READINGS</i></u></h1><br>
        <nav class="tabs">
            <li><a href="home.php">HOME</a></li>
            <li><a href="information.php">INFORMATION</a></li>
            <li><a href="appointment.php">APPOINTMENT</a></li>
            <li><a href="contact.php">CONTACT</a></li>
        </nav>
    </header>
    <?php 
        require_once "connect.php";   // connect to sql database 
        $query = "SELECT * FROM jec229.readers";
        $result = $conn->query($query);
        if (!$result) die("Fatal Error when querying SQL table.");
        $rows = $result->num_rows; 
    ?>

    <br><br><br>
    <div class="bodytext">
        <br>
        <h3>Book an Appointment Here!</h3><br>
        <form action="insert.php" method="post">
            First Name: <input type="text" id="fname" name="fname" placeholder="Jane" required="required"><br><br>
            Last Name: <input type="text" id="lname" name="lname" placeholder="Doe" required="required"><br><br>
            Email: <input type="email" id="email" name="email" placeholder="jdoe@email.com" required="required"><br><br><br>

            Please select the tarot reader that you would like to have a session with.<br><br>
            <!-- names randomly generated; not real people! -->
            <?php
            for ($j=0; $j<$rows; ++$j) {
            // data_seek is a php function used to collect data from a particular row ($j)  
                echo '<input type="radio" id="reader" name="reader" value="reader" required="required">';
                $result->data_seek($j);
                echo htmlspecialchars($result->fetch_assoc()['reader']);
                echo "&nbsp;&nbsp;";
                $result->data_seek($j);
                echo htmlspecialchars($result->fetch_assoc()['rating']);
                echo "<br><br>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut id lacus at velit lobortis lobortis. Curabitur erat nibh, pulvinar at semper quis, fermentum quis tortor. Proin sit amet nibh consectetur, mattis dui sit amet, posuere mauris. Morbi tempus quis nisl sed imperdiet. Donec odio massa, semper sit amet imperdiet ut, porta id nisl. Aliquam nec mauris nisl. Pellentesque vitae nisi vestibulum, malesuada mi a, dapibus justo. Nam at metus lacus. Sed pulvinar est et lacus euismod posuere. Sed rhoncus libero interdum, consectetur augue non, porttitor erat.<br><br><br>";
            }
            ?>

            Please choose a date and time: <select name="date_time" id="date_time" required="required">
                <option value="08-01-2021 Sunday 07:00:00 AM">08-01-2021 Sunday 07:00:00 AM</option>
                <option value="08-01-2021 Sunday 07:30:00 AM">08-01-2021 Sunday 07:30:00 AM</option>
                <option value="08-02-2021 Monday 08:00:00 AM">08-02-2021 Monday 08:00:00 AM</option>
                <option value="08-02-2021 Monday 08:30:00 AM">08-02-2021 Monday 08:30:00 AM</option>
                <option value="08-03-2021 Tuesday 09:00:00 AM">08-03-2021 Tuesday 09:00:00 AM</option>
                <option value="08-03-2021 Tuesday 09:30:00 AM">08-03-2021 Tuesday 09:30:00 AM</option>
                <option value="08-04-2021 Wednesday 10:00:00 AM">08-04-2021 Wednesday 10:00:00 AM</option>
                <option value="08-04-2021 Wednesday 10:30:00 AM">08-04-2021 Wednesday 10:30:00 AM</option>
                <option value="08-05-2021 Thursday 11:00:00 AM">08-05-2021 Thursday 11:00:00 AM</option>
                <option value="08-05-2021 Thursday 11:30:00 AM">08-05-2021 Thursday 11:30:00 AM</option>
            </select><br><br>
            <input type="checkbox" id="terms/services" name="terms/services" required="required" />I have read and understand the terms and services in its entirety.<br><br>
            <input type="submit" name="submit" value="Submit">
        </form>
    </div>
    <footer>
        <nav class="tarotcopy">
            JEN'S TAROT READINGS &copy; 2021 English (US)
        </nav>
    </footer>
</body>

</html>
