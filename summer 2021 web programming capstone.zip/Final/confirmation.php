<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Final</title>
    <meta name="description" content="Final">
    <meta name="author" content="Jen Chen">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <header>
        <h1><u><i>JEN'S TAROT READINGS</i></u></h1><br>
        <nav class="tabs">
            <li><a href="home.php">HOME</a></li>
            <li><a href="information.php">INFORMATION</a></li>
            <li><a href="appointment.php">APPOINTMENT</a></li>
            <li><a href="contact.php">CONTACT</a></li>
        </nav>
    </header>
    <?php
    include "connect.php";
    echo "<br><br><br>";
    echo "<h4>Your submission has successfully been processed. Please check your email for any updates and/or new information. Thank you!</h4><br>";
    echo "<a href=''>hypothetical zoom link</a>"
    ?>
</body>

</html>
