<?php
include "connect.php";  // connect to sql database

    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $dateandtime = $_POST['date_time'];

    $insert = "INSERT INTO appointment (fname, lname, email, date_time) VALUES('$fname', '$lname', '$email', '$dateandtime')";
    
    if(mysqli_query($conn, $insert)){
    header("Location: confirmation.php");
} else{
    echo "ERROR: Could not able to execute $insert. " . mysqli_error($conn);
}
    mysqli_close($conn);    // close connection
?>
