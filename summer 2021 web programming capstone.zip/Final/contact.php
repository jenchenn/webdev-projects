<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Final</title>
    <meta name="description" content="Final">
    <meta name="author" content="Jen Chen">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <header>
        <h1><u><i>JEN'S TAROT READINGS</i></u></h1><br>
        <nav class="tabs">
            <li><a href="home.php">HOME</a></li>
            <li><a href="information.php">INFORMATION</a></li>
            <li><a href="appointment.php">APPOINTMENT</a></li>
            <li><a href="contact.php">CONTACT</a></li>
        </nav>
    </header>
    <?php 
        require_once "connect.php";
    ?>
    <br><br><br>
    <div class="bodytext">
        <br>
        <h3>Contact/Feedback</h3><br>
        <form action="confirmation.php" method="post">
            First Name: <input type="text" id="fname" name="fname" placeholder="Jane" required="required"><br><br>
            Last Name: <input type="text" id="lname" name="lname" placeholder="Doe" required="required"><br><br>
            Email: <input type="email" id="email" name="email" placeholder="jdoe@email.com" required="required"><br><br>
            Comment: <br><textarea name="comment" placeholder="Enter any questions, comments, or concerns here..." required="required" cols="50" rows="20" value=""></textarea><br><br>
            <input type="submit" name="submit" value="Submit">
        </form>
    </div>
    <footer>
        <nav class="tarotcopy">
            JEN'S TAROT READINGS &copy; 2021 English (US)
        </nav>
    </footer>
</body>

</html>
