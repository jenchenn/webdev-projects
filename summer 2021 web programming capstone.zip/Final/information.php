<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Final</title>
    <meta name="description" content="Final">
    <meta name="author" content="Jen Chen">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <header>
        <h1><u><i>JEN'S TAROT READINGS</i></u></h1><br>
        <nav class="tabs">
            <li><a href="home.php">HOME</a></li>
            <li><a href="information.php">INFORMATION</a></li>
            <li><a href="appointment.php">APPOINTMENT</a></li>
            <li><a href="contact.php">CONTACT</a></li>
        </nav>
    </header>
    <?php 
        require_once "connect.php";   // connect to sql database 
        $query = "SELECT * FROM jec229.cards";
        $result = $conn->query($query);
        if (!$result) die("Fatal Error when querying SQL table.");
        $rows = $result->num_rows; 
    ?>
    <br><br><br>
    <div class="bodytext">
        <br>
        <h3>What are tarot cards?</h3><br>
        <h4>The tarot (/ˈtæroʊ/, first known as trionfi and later as tarocchi or tarock) is a pack of playing cards, used from the mid-15th century in various parts of Europe to play games such as Italian tarocchini, French tarot and Austrian Königrufen, many of which are still played today. In the late 18th century, some tarot decks began to be used for divination via tarot card reading and cartomancy leading to custom decks developed for such occult purposes.<br><br>Like the common playing cards, tarot has four suits which vary by region: French suits in Northern Europe, Latin suits in Southern Europe, and German suits in Central Europe. Each suit has 14 cards: ten pip cards numbering from one (or Ace) to ten, and four face cards (King, Queen, Knight, and Jack/Knave/Page). In addition, the tarot has a separate 21-card trump suit and a single card known as the Fool; this 22-card section of the tarot deck is known as the major arcana. Depending on the game, the Fool may act as the top trump or may be played to avoid following suit. These tarot cards are still used throughout much of Europe to play conventional card games without occult associations.<br><br>Among English-speaking countries where these games are not played frequently, tarot cards are used primarily for novelty and divinatory purposes, usually using specially designed packs. Some who use tarot for cartomancy believe that the cards have esoteric links to ancient Egypt, the Kabbalah, Indian Tantra, or the I Ching, though scholarly research has demonstrated that tarot cards were invented in north Italy in the 15th century and confirmed that there is no clear evidence of the usage of tarot for divination before the 18th century.</h4><br><br><br>
        <h3>What is a tarot card reading?</h3><br>
        <h4>Tarot card reading is a form of cartomancy whereby practitioners use tarot cards purportedly to gain insight into the past, present or future. They formulate a question, then draw cards interpret them for this end. A regular tarot deck consists of 78 cards, which can be split into two groups, the major arcana and minor arcana.</h4><br><br><br>
        <h3>What are the different types of cards?</h3><br>
        <h4>A standard tarot deck has 78 cards, divided into 2 groups; 22 major arcana cards and 56 minor arcana cards. In the tarot, the major arcana denote important life events, lessons or milestones, while the minor arcana cards reflect day-to-day events. The minor arcana cards are arranged into 4 suits - swords, pentacles, wands, and cups. Each suit has a ruling element and correspond to a specific area of life: Swords represent air and have to do with intellect and decisions. Pentacles represent earth, money and achievement. Wands represent fire and action. Cups represent water and emotions. Court Cards represent a person - either yourself or someone else. They reflect personality traits and characteristics, and can give insight into motives.</h4><br><br><br>
        <h3>What does each card mean?</h3><br>
        <h4> <?php echo "<table><tr><th>Name</th><th>Meaning</th></tr>";
            for ($j=0; $j<$rows; ++$j) { // data_seek is a php function used to collect data from a particular row ($j)
                $result->data_seek($j);
                echo "<tr><td>".htmlspecialchars($result->fetch_assoc()['name'])."</td>";
                $result->data_seek($j);
                echo "<td>".htmlspecialchars($result->fetch_assoc()['meaning'])."</td></tr>";
            }
            echo "</table>";
            mysqli_close($conn);?></h4>
    </div>
    <footer>
        <nav class="tarotcopy">
            TAROT READINGS &copy; 2021 English (US)
        </nav>
    </footer>
</body>

</html>
