<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Midterm</title>
    <meta name="description" content="Midterm">
    <meta name="author" content="Jen Chen">
    </head>

<body>
<?php
    require_once 'connect.php'; //connect to SQL database
    echo "<h1>SOURCE CODE: I TRIED MY BEST :(</h1>";
    
    echo "<img src='Forum EER Diagram Screenshot.png'>";
    echo "<p>connect.php (not shown for security purposes)</p>";
    echo "<p>login.php</p>"; 
    show_source("login.php");
    echo "<p>forummain.php</p>"; 
    show_source("forummain.php");
    echo "<p>catview.php</p>"; 
    show_source("catview.php");
    echo "<p>posttopic.php</p>"; 
    show_source("posttopic.php");
    echo "<p>topicview.php</p>"; 
    show_source("topicview.php");
    echo "<p>postreply.php</p>"; 
    show_source("postreply.php");
    echo "<p>thankyou.php</p>"; 
    show_source("thankyou.php");
?>