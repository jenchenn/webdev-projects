<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Midterm</title>
    <meta name="description" content="Midterm">
    <meta name="author" content="Jen Chen">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
<?php require_once "connect.php";   // connect to sql database ?>
    <h1><a href='forummain.php'>Major Arcana Forum</a></h1><br>
    <h3>Welcome to Jen's Major Arcana Forum, a forum inspired by the Major Arcana tarot card deck.</h3><br>
    <h4>The Major Arcana is a 22 card set within the tarot that is considered to be the core and the foundation for the deck. All of the deck is filled with archetypal significance, but this is most pronounced within the Major Arcana. These cards follow a storyline that tells of the spiritual travels taken from the innocent wonder of The Fool to the oneness and fulfillment of The World. In other words, these cards tell the story of humanity's spiritual evolution into enlightenment and individuation.</h4><br>
    
    <form action="postreply.php" method="post">
        <h3>Comment:</h3><textarea name="comment" cols="50" rows="10" value=""></textarea><br><br>
        <input name="submit" type="button" value="Post Reply" onClick="window.location.href='thankyou.php'" />
        <input name="cancel" type="button" value="Cancel" onClick="window.location.href='forummain.php'" />
    </form>
    
<?php
    //take all values from form data
    if ($result = $conn->query($query)) {
        $message = $_POST['comment'];
        $timestamp = date('Y-m-d h:i a', time());
        $userID_fk = $_POST['userID_fk'];
        $topicID_fk = $_POST['topicID_fk'];
    }
        
    $query = "INSERT INTO replies (message, timestamp, userID_fk, topicID_fk) VALUES ('{$message}','{$timestamp}','{$userID_fk}','{$topicID_fk}')";
    $result = $conn->query($query);
    
    // test for any query errors 
    if (!$result) {
        die ("Database query failed.");
    }
    mysqli_close($conn);   
?>
</body>

</html>
