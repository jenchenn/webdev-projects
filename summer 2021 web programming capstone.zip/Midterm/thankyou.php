<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Midterm</title>
    <meta name="description" content="Midterm">
    <meta name="author" content="Jen Chen">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
<?php
    include "connect.php";
    echo "<h1><a href='forummain.php'>Major Arcana Forum</a></h1><br>";
    echo "<h3>Welcome to Jen's Major Arcana Forum, a forum inspired by the Major Arcana tarot card deck.</h3><br>";
    echo "<h4>Your submission has successfully been processed. Thank you!</h4>";
?>
</body>

</html>
