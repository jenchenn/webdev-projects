<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Midterm</title>
    <meta name="description" content="Midterm">
    <meta name="author" content="Jen Chen">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <?php require_once "connect.php";   // connect to sql database ?>
    <h1><u>Major Arcana Forum</u></h1><br>
    <h3>Welcome to Jen's Major Arcana Forum, a forum inspired by the Major Arcana tarot card deck.</h3><br>
    <h4>The Major Arcana is a 22 card set within the tarot that is considered to be the core and the foundation for the deck. All of the deck is filled with archetypal significance, but this is most pronounced within the Major Arcana. These cards follow a storyline that tells of the spiritual travels taken from the innocent wonder of The Fool to the oneness and fulfillment of The World. In other words, these cards tell the story of humanity's spiritual evolution into enlightenment and individuation.</h4>
    <h5>**I TRIED MY BEST :(**</h5><br>

    <form action="" method="post">
        Username: <input type="text" name="username" required="required">
        <br><br>
        Password: <input type="text" name="password" required="required">
        <br><br>
        <input type="submit" name="submit" value="Login">
        <br><br>
    </form>

<?php   // login validation
    if($_POST) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        if($username == "test" && $password == "test") {
            // redirects to forum page
            header("Location: forummain.php"); 
        } else {
            die ("Please enter a valid username and password.");
        }
    } 
?>
</body>

</html>
