<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Midterm</title>
    <meta name="description" content="Midterm">
    <meta name="author" content="Jen Chen">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
<?php
    require_once "connect.php"; // connect to sql database
    $query = "SELECT * FROM jec229.topics";
    $result = $conn->query($query);
    if (!$result) die("Fatal Error when querying SQL table.");
    $rows = $result->num_rows;
    
    echo "<h1><a href='forummain.php'>Major Arcana Forum</a></h1><br>";
    echo "<h3>Welcome to Jen's Major Arcana Forum, a forum inspired by the Major Arcana tarot card deck.</h3><br>";
    echo "<h4>The Major Arcana is a 22 card set within the tarot that is considered to be the core and the foundation for the deck. All of the deck is filled with archetypal significance, but this is most pronounced within the Major Arcana. These cards follow a storyline that tells of the spiritual travels taken from the innocent wonder of The Fool to the oneness and fulfillment of The World. In other words, these cards tell the story of humanity's spiritual evolution into enlightenment and individuation.</h4>";
    echo "<br><br>";
    
    echo "<table>";
    echo "<tr><th>Topics</th>
          <th>Topic Creators</th>
          <th>Date</th></tr>";
    
    for ($j=0; $j<$rows; ++$j) {
        // data_seek is a php function used to collect data from a particular row ($j)  
        $topicID = $_GET['topicID'];
        $result->data_seek($j);
        echo "<tr><td><a href='topicview.php?topicID=".$topicID."'>".htmlspecialchars($result->fetch_assoc()['title'])."</td>";
        $result->data_seek($j);
        echo "<td>".htmlspecialchars($result->fetch_assoc()['userID_fk'])."</td>";
        $result->data_seek($j);
        echo "<td>".htmlspecialchars($result->fetch_assoc()['timestamp'])."</td></tr>";
    }
    echo "</table>";
    echo "<br>";
    mysqli_close($conn);
?>
    <input name="newtopic" type="button" value="Add New Topic" onClick="window.location.href='posttopic.php'" />
</body>

</html>
