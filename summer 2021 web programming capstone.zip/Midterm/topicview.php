<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Midterm</title>
    <meta name="description" content="Midterm">
    <meta name="author" content="Jen Chen">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
<?php
    require_once "connect.php"; // connect to sql database
    $query = "SELECT * FROM jec229.replies";
    $result = $conn->query($query);
    // test for any query errors 
    if (!$result) {
        die ("Database query failed.");
    }
    $rows = $result->num_rows;
    
    echo "<h1><a href='forummain.php'>Major Arcana Forum</a></h1><br>";
    echo "<h3>Welcome to Jen's Major Arcana Forum, a forum inspired by the Major Arcana tarot card deck.</h3><br>";
    echo "<h4>The Major Arcana is a 22 card set within the tarot that is considered to be the core and the foundation for the deck. All of the deck is filled with archetypal significance, but this is most pronounced within the Major Arcana. These cards follow a storyline that tells of the spiritual travels taken from the innocent wonder of The Fool to the oneness and fulfillment of The World. In other words, these cards tell the story of humanity's spiritual evolution into enlightenment and individuation.</h4>";
    echo "<br><br>";
    
    echo "<table>";
    echo "<tr><th>Message</th>
          <th>User</th>
          <th>Date</th></tr>";
    
    for ($j=0; $j<$rows; ++$j) {
        // data_seek is a php function used to collect data from a particular row ($j)  
        $result->data_seek($j);
        echo "<tr><td>".htmlspecialchars($result->fetch_assoc()['message'])."</td>";
        $result->data_seek($j);
        echo "<td>".htmlspecialchars($result->fetch_assoc()['userID_fk'])."</td>";
        $result->data_seek($j);
        echo "<td>".htmlspecialchars($result->fetch_assoc()['timestamp'])."</td></tr>";
    }
    echo "</table>";
    echo "<br>";
    mysqli_close($conn);
?>
    <input name="reply" type="button" value="Reply" onClick="window.location.href='postreply.php'"/>
</body>

</html>